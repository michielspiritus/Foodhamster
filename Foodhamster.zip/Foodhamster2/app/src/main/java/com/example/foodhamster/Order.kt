package com.example.foodhamster

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Order :AppCompatActivity()
{
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order2)



    }

}